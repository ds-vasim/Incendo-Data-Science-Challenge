#xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

#xxxxxxxxxxxxxxxxxx Import Libraries and set path xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx#


#xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

# Install Missing Packages Autoamtically.
list.of.packages <- c("lubridate", "readxl","h2o","mice","VIM","Hmisc","dplyr","caret","tidyr","stringr","corrplot","reshape")
new.packages <- list.of.packages[!(list.of.packages %in% installed.packages()[,"Package"])]
if(length(new.packages)) install.packages(new.packages)




# Load Libraries
library(h2o) # for data modelling
library(mice)  #Missing Values Imputation 
library(VIM) #plotting
library(Hmisc) # Imputing Missing Values
library(caret)  # For ML operations
library(tidyr) # for cleaning data
library(stringr) # for cleaning text data
library(corrplot) # for correlation plotting
library(reshape)  # for reshaping dataframes


setwd("D:/Dropbox (eClerx Services Ltd.)/Gaurav Profile/Desktop/New folder/Incendo/01")


# Import Train, Test, Sample SUbmission  files

train <- read.csv("train_file.csv", na.strings="")

test<- read.csv("test_file.csv", na.strings="")



#xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx


#xxxxxxxxxxxxx Data Preparation  xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx#


#xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

# Get summary of training data
summary(train)
str(train)



#== Missing Values ==#
colSums(is.na(train))
# GeoLocation 3301


# Remove Patient_ID from train as well as test as ML model generated should be 
# expalainable via features and not ID's

train$Patient_ID <- NULL
test$Patient_ID <- NULL


# --- LocationDesc ----#
# Convert Location description into City and Code

temp1 <- transform(train, LocationDesc = colsplit(LocationDesc, split = ",", names = c('City', 'Code')))

train$City <- temp1$LocationDesc$City
train$Code <-  temp1$LocationDesc$Code

train$LocationDesc <- NULL


rm(temp1)


temp1 <- transform(test, LocationDesc = colsplit(LocationDesc, split = ",", names = c('City', 'Code')))

test$City <- temp1$LocationDesc$City
test$Code <-  temp1$LocationDesc$Code

test$LocationDesc <- NULL

rm(temp1)



#-------------- Feature Preparation ---------------------------------#

# 1. Identifying and converting Categorical variables

# SUb Topic
unique(unique(train$Subtopic) %in% unique(test$Subtopic))

#  Encoding 0 to "Alcohol" and 1 to "Ohter Drugs"

train$Subtopic[train$Subtopic==0] <- "Alcohol"
train$Subtopic[train$Subtopic==1] <- "Other_Drugs"

test$Subtopic[test$Subtopic==0] <- "Alcohol"
test$Subtopic[test$Subtopic==1] <- "Other_Drugs"


train$Subtopic <- as.factor(train$Subtopic)
test$Subtopic <- as.factor(test$Subtopic)


# "Greater_Risk_Question"   "Description"
table(train$Subtopic,train$Greater_Risk_Question)

a1 <- as.data.frame(table(train$Greater_Risk_Question,train$Description))

a2 <- a1[a1$Freq!=0,]

unique(train$Greater_Risk_Question)
unique(train$Description)


#--- Thre are 20 unique  Greater_Risk_Question and for each Greater_Risk_Question there is unique Description
#--- Hence Description column can be dropped

train$Description <- NULL
test$Description <- NULL

rm(a1,a2)



#== Grade
unique(unique(train$Grade) %in% unique(test$Grade))

#--- Convert Numerical Grades into Categroies --------------#
train$Grade[train$Grade==0] <-"No_Grade"
train$Grade[train$Grade==1] <-"Grade_1"
train$Grade[train$Grade==2] <-"Grade_2"
train$Grade[train$Grade==3] <-"Grade_3"
train$Grade[train$Grade==4] <-"Grade_4"

train$Grade <- as.factor(train$Grade)



test$Grade[test$Grade==0] <-"No_Grade"
test$Grade[test$Grade==1] <-"Grade_1"
test$Grade[test$Grade==2] <-"Grade_2"
test$Grade[test$Grade==3] <-"Grade_3"
test$Grade[test$Grade==4] <-"Grade_4"

test$Grade <- as.factor(test$Grade)

#== StratID1
unique(unique(train$StratID1) %in% unique(test$StratID1))

train$StratID1[train$StratID1==0] <- "Strat1_0"
train$StratID1[train$StratID1==1] <- "Strat1_1"
train$StratID1[train$StratID1==2] <- "Strat1_2"

train$StratID1 <- as.factor(train$StratID1)


test$StratID1[test$StratID1==0] <- "Strat1_0"
test$StratID1[test$StratID1==1] <- "Strat1_1"
test$StratID1[test$StratID1==2] <- "Strat1_2"

test$StratID1 <- as.factor(test$StratID1)

#== StratID2
unique(unique(train$StratID2) %in% unique(test$StratID2))

train$StratID2[train$StratID2==0] <- "Strat2_0"
train$StratID2[train$StratID2==1] <- "Strat2_1"
train$StratID2[train$StratID2==2] <- "Strat2_2"
train$StratID2[train$StratID2==3] <- "Strat2_3"
train$StratID2[train$StratID2==4] <- "Strat2_4"
train$StratID2[train$StratID2==5] <- "Strat2_5"
train$StratID2[train$StratID2==6] <- "Strat2_6"
train$StratID2[train$StratID2==7] <- "Strat2_7"

train$StratID2 <- as.factor(train$StratID2)



test$StratID2[test$StratID2==0] <- "Strat2_0"
test$StratID2[test$StratID2==1] <- "Strat2_1"
test$StratID2[test$StratID2==2] <- "Strat2_2"
test$StratID2[test$StratID2==3] <- "Strat2_3"
test$StratID2[test$StratID2==4] <- "Strat2_4"
test$StratID2[test$StratID2==5] <- "Strat2_5"
test$StratID2[test$StratID2==6] <- "Strat2_6"
test$StratID2[test$StratID2==7] <- "Strat2_7"

test$StratID2 <- as.factor(test$StratID2)


#== StratID3
unique(unique(train$StratID3) %in% unique(test$StratID3))

train$StratID3[train$StratID3==0] <- "Strat3_0"
train$StratID3[train$StratID3==1] <- "Strat3_1"
train$StratID3[train$StratID3==2] <- "Strat3_2"
train$StratID3[train$StratID3==3] <- "Strat3_3"
train$StratID3[train$StratID3==4] <- "Strat3_4"


train$StratID3 <- as.factor(train$StratID3)



test$StratID3[test$StratID3==0] <- "Strat3_0"
test$StratID3[test$StratID3==1] <- "Strat3_1"
test$StratID3[test$StratID3==2] <- "Strat3_2"
test$StratID3[test$StratID3==3] <- "Strat3_3"
test$StratID3[test$StratID3==4] <- "Strat3_4"


test$StratID3 <- as.factor(test$StratID3)


# #-------------- Dealing with GeoLocation ---------------#
train$GeoLocation <- as.character(train$GeoLocation)

# Remove Brackets 
train$GeoLocation <- gsub("\\(|\\)", "", train$GeoLocation)


temp1 = transform(train, GeoLocation = colsplit(GeoLocation, split = "\\,", names = c('latitude', 'longitude')))

train$latitude <- temp1$GeoLocation$latitude
train$longitude <- temp1$GeoLocation$longitude


rm(temp1)



test$GeoLocation <- as.character(test$GeoLocation)

# Remove Brackets 
test$GeoLocation <- gsub("\\(|\\)", "", test$GeoLocation)


temp1 = transform(test, GeoLocation = colsplit(GeoLocation, split = "\\,", names = c('latitude', 'longitude')))

test$latitude <- temp1$GeoLocation$latitude
test$longitude <- temp1$GeoLocation$longitude


rm(temp1)

train$GeoLocation <- NULL
test$GeoLocation <- NULL




# 2. ------------ Continuous variables -----------------#


# Sample_Size
boxplot(train$Sample_Size)

boxplot(sin(train$Sample_Size))

# Normalizing Distribution
train$Sample_Size <- sin(train$Sample_Size)

test$Sample_Size <- sin(test$Sample_Size)


#===========================  Missing Value Imputation ===========================
colSums(is.na(train))

colSums(is.na(test))

# impute with mean  value
temp1 <- with(train, impute(latitude, mean))

write.csv(temp1,"latitude_train.csv",row.names = F)

temp1 <- read.csv("latitude_train.csv",stringsAsFactors = T)

train$latitude <- temp1$x


rm(temp1)

temp1 <- with(test, impute(latitude, mean))

write.csv(temp1,"latitude_test.csv",row.names = F)

temp1 <- read.csv("latitude_test.csv",stringsAsFactors = T)

test$latitude <- temp1$x


rm(temp1)

# For Longitude 
# impute with mean  value
temp1 <- with(train, impute(longitude, mean))

write.csv(temp1,"longitude_train.csv",row.names = F)

temp1 <- read.csv("longitude_train.csv",stringsAsFactors = T)

train$longitude <- temp1$x


rm(temp1)

temp1 <- with(test, impute(longitude, mean))

write.csv(temp1,"longitude_test.csv",row.names = F)

temp1 <- read.csv("longitude_test.csv",stringsAsFactors = T)

test$longitude <- temp1$x


rm(temp1)


# Normalizing Distribution

boxplot(train$latitude)
boxplot(sin(train$latitude))


train$latitude <- sin(train$latitude)
test$latitude <- sin(test$latitude)


boxplot(train$longitude)
boxplot(sin(train$longitude))

train$longitude <- sin(train$longitude)
test$longitude <- sin(test$longitude)





#xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

#---------------- Training using H2o ------------------#

#xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

h2o.init()


output <- "Greater_Risk_Probability"
input  <- setdiff( names(train), output )

train = as.h2o(train)


# Predictive Modelling for 1 hour

aml <- h2o.automl(y = output,x = input,training_frame = train,nfolds = 7,seed = 123,max_runtime_secs = 3600,stopping_metric = "RMSE",exclude_algos = c("DeepLearning"))


# check the leaderboard
lb <- aml@leaderboard
lb

# get model ids  for all models 
model_ids <- as.data.frame(aml@leaderboard$model_id)[,1]

# Get all model stacked ensembled model
se <- h2o.getModel(grep("StackedEnsemble_AllModels",model_ids,value = TRUE)[1])

metalearner <- h2o.getModel(se@model$metalearner$name)

h2o.varimp(metalearner)

gbm <- h2o.getModel(grep("GBM",model_ids,value=TRUE)[1])

imp  <- as.data.frame(h2o.varimp(gbm))

h2o.varimp_plot(gbm)

#-------------- Make Predictions -------------------------#
test = as.h2o(test)


pred <- h2o.predict(gbm, test)

pred = as.data.frame(pred)


sample_submission <- read.csv("test_file.csv", na.strings="")

sample_submission$Greater_Risk_Probability <- pred$predict

sample_submission <- sample_submission[,c(1,17)]



write.csv(sample_submission,"h2o_Automl.csv",row.names = F)


library(xlsx)

write.xlsx(sample_submission,"h2o_Automl.xlsx",row.names = F)


